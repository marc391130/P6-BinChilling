!Bin Chilling: A Metagenomic Ensemble Method

Dockerfile might not work.

only tested on linux.
How to run:

1. pip install -r requirements.txt
2. python3 BinChilling -h
3. follow guide
