ACID_LABELS = ['A', 'T', 'G', 'C']
ACID_SET = set('ATGCC')
COMPOSITION_CONSTANT = 4
COMPOSITION_COUNT = 136
FASTA_FILEPATH = "../Dataset/edges.fasta"
ABUNDANCE_FILEPATH = "../Dataset/edges_depth.txt"
SCG_FILEPATH = "../Dataset/marker_gene_stats.tsv"
MERGED_CLUSTER = -1